import { Suspense } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import { Toaster } from "./components/ui/sonner";
import SplashScreen from "./pages/SplashScreen";
import HomeScreen from "./pages/HomeScreen";
import AuthScreen from "./pages/AuthScreen";
import Dashboard from "./pages/Dashboard";
import { Loader2 } from "lucide-react";

function App() {
  return (
    <AuthProvider>
      <Suspense 
        fallback={
          <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
            <Loader2 className="w-12 h-12 animate-spin neon-glow-green" />
          </div>
        }
      >
        <Routes>
          <Route path="/" element={<SplashScreen />} />
          <Route path="/home" element={<HomeScreen />} />
          <Route path="/auth" element={<AuthScreen />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/dashboard/:tab" element={<Dashboard />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        <Toaster 
          position="top-right"
          toastOptions={{
            style: {
              background: '#0A0A0A',
              color: '#fff',
              border: '2px solid #00FF41',
            },
          }}
        />
      </Suspense>
    </AuthProvider>
  );
}

export default App;
