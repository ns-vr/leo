import { useState } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ShoppingCart, Music, Tag, Upload } from 'lucide-react';
import { toast } from 'sonner';

const merchItems = [
  {
    id: 1,
    title: 'NEON GRAFFITI HOODIE',
    price: 89.99,
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800&q=80',
    category: 'clothes',
  },
  {
    id: 2,
    title: 'CYBER STREET JACKET',
    price: 129.99,
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&q=80',
    category: 'clothes',
  },
  {
    id: 3,
    title: 'URBAN NEON TEE',
    price: 39.99,
    image: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=800&q=80',
    category: 'clothes',
  },
  {
    id: 4,
    title: 'AUDIO QR KEYCHAIN',
    price: 24.99,
    image: 'https://images.unsplash.com/photo-1611858518726-829c65f30c0b?w=800&q=80',
    category: 'keychains',
  },
  {
    id: 5,
    title: 'LED GLOW KEYCHAIN',
    price: 29.99,
    image: 'https://images.unsplash.com/photo-1590736969955-71cc94901144?w=800&q=80',
    category: 'keychains',
  },
  {
    id: 6,
    title: 'HOLOGRAPHIC KEYCHAIN',
    price: 19.99,
    image: 'https://images.unsplash.com/photo-1624823183493-ed5832f48f18?w=800&q=80',
    category: 'keychains',
  },
];

export default function MerchSection() {
  const [cart, setCart] = useState<number[]>([]);

  const addToCart = (itemId: number) => {
    setCart([...cart, itemId]);
    toast.success('Added to cart! 🛒', {
      style: {
        background: '#0A0A0A',
        color: '#10B981',
        border: '1px solid #10B981',
      },
    });
  };

  return (
    <div className="space-y-8">
      <Tabs defaultValue="clothes" className="w-full">
        <TabsList className="w-full grid grid-cols-3 bg-black/50 border border-emerald-500/50 rounded-lg">
          <TabsTrigger value="clothes" className="data-[state=active]:text-emerald-400 data-[state=active]:bg-black/70">
            <Tag className="w-4 h-4 mr-2" />
            CLOTHES
          </TabsTrigger>
          <TabsTrigger value="playlists" className="data-[state=active]:text-amber-400 data-[state=active]:bg-black/70">
            <Music className="w-4 h-4 mr-2" />
            PLAYLISTS
          </TabsTrigger>
          <TabsTrigger value="keychains" className="data-[state=active]:text-fuchsia-400 data-[state=active]:bg-black/70">
            <Tag className="w-4 h-4 mr-2" />
            KEYCHAINS
          </TabsTrigger>
        </TabsList>

        <TabsContent value="clothes" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {merchItems
              .filter((item) => item.category === 'clothes')
              .map((item, i) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                >
                  <Card className="border border-emerald-500/50 bg-black/80 overflow-hidden group cursor-pointer">
                    <div className="aspect-square overflow-hidden relative">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                    </div>
                    <div className="p-6">
                      <h4 className="text-xl font-bold text-emerald-400 mb-2" style={{ fontFamily: 'Bangers, cursive' }}>
                        {item.title}
                      </h4>
                      <p className="text-2xl font-bold text-white mb-4">${item.price}</p>
                      <Button
                        onClick={() => addToCart(item.id)}
                        className="w-full border border-emerald-500/50 bg-black hover:bg-emerald-500/10 text-emerald-400"
                        style={{ fontFamily: 'Bangers, cursive' }}
                      >
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        BUY NOW
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              ))}

            {/* Custom Jacket Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              whileHover={{ scale: 1.05 }}
            >
              <Card className="border border-cyan-500/50 bg-black/80 overflow-hidden group cursor-pointer h-full flex flex-col justify-center items-center p-8">
                <Upload className="w-16 h-16 text-cyan-400 mb-4" />
                <h4 className="text-2xl font-bold text-cyan-400 mb-2 text-center" style={{ fontFamily: 'Bangers, cursive' }}>
                  CREATE CUSTOM JACKET
                </h4>
                <p className="text-gray-400 text-center mb-4">
                  Upload your photo and let AI create a unique neon design
                </p>
                <Button
                  className="border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  START DESIGNING
                </Button>
              </Card>
            </motion.div>
          </div>
        </TabsContent>

        <TabsContent value="playlists" className="mt-8">
          <div className="max-w-2xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="border border-amber-500/50 bg-black/90 p-8 rounded-lg"
            >
              <div className="flex items-center gap-4 mb-6">
                <Music className="w-12 h-12 text-amber-400" />
                <div>
                  <h3 className="text-3xl font-bold text-amber-400" style={{ fontFamily: 'Bangers, cursive' }}>
                    UNDERGROUND HYPE
                  </h3>
                  <p className="text-gray-400">Curated street art vibes</p>
                </div>
              </div>

              {/* Spotify Embed */}
              <div className="aspect-video bg-black border border-amber-500/50 overflow-hidden rounded">
                <iframe
                  src="https://open.spotify.com/embed/playlist/6q9mNqQgNJAdKQ3cNycERT?utm_source=generator&theme=0"
                  width="100%"
                  height="100%"
                  frameBorder="0"
                  allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                  loading="lazy"
                  className="w-full h-full"
                />
              </div>

              <div className="mt-6 space-y-4">
                <p className="text-gray-300">
                  Vibe out to this carefully curated playlist of underground bangers, 
                  street anthems, and hype tracks that match the Leo energy.
                </p>
                <Button
                  className="w-full border border-amber-500/50 bg-black hover:bg-amber-500/10 text-amber-400"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  <Music className="w-4 h-4 mr-2" />
                  OPEN IN SPOTIFY
                </Button>
              </div>
            </motion.div>
          </div>
        </TabsContent>

        <TabsContent value="keychains" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {merchItems
              .filter((item) => item.category === 'keychains')
              .map((item, i) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                >
                  <Card className="border border-fuchsia-500/50 bg-black/80 overflow-hidden group cursor-pointer">
                    <div className="aspect-square overflow-hidden relative">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                    </div>
                    <div className="p-6">
                      <h4 className="text-xl font-bold text-fuchsia-400 mb-2" style={{ fontFamily: 'Bangers, cursive' }}>
                        {item.title}
                      </h4>
                      <p className="text-2xl font-bold text-white mb-4">${item.price}</p>
                      <Button
                        onClick={() => addToCart(item.id)}
                        className="w-full border border-fuchsia-500/50 bg-black hover:bg-fuchsia-500/10 text-fuchsia-400"
                        style={{ fontFamily: 'Bangers, cursive' }}
                      >
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        BUY NOW
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              ))}

            {/* Custom Keychain Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              whileHover={{ scale: 1.05 }}
            >
              <Card className="border border-cyan-500/50 bg-black/80 overflow-hidden group cursor-pointer h-full flex flex-col justify-center items-center p-8">
                <Upload className="w-16 h-16 text-cyan-400 mb-4" />
                <h4 className="text-2xl font-bold text-cyan-400 mb-2 text-center" style={{ fontFamily: 'Bangers, cursive' }}>
                  CREATE CUSTOM KEYCHAIN
                </h4>
                <p className="text-gray-400 text-center mb-4">
                  Upload image, add audio message, generate QR code
                </p>
                <Button
                  className="border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  START DESIGNING
                </Button>
              </Card>
            </motion.div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Cart Indicator */}
      {cart.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed bottom-20 md:bottom-8 right-8 border border-emerald-500/50 bg-black/90 backdrop-blur-lg p-4 rounded-full shadow-2xl"
        >
          <Button
            size="lg"
            className="border border-emerald-500/50 bg-black hover:bg-emerald-500/10 text-emerald-400 rounded-full h-16 w-16 relative"
          >
            <ShoppingCart className="w-6 h-6" />
            <span className="absolute -top-2 -right-2 bg-fuchsia-500 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">
              {cart.length}
            </span>
          </Button>
        </motion.div>
      )}
    </div>
  );
}
