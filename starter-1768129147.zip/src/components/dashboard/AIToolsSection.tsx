import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Upload, Download, Share2, Loader2, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

export default function AIToolsSection() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processedImages, setProcessedImages] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        setProcessedImages([]);
        toast.success('Image uploaded! Ready to transform 🎨');
      };
      reader.readAsDataURL(file);
    }
  };

  const transformWithAI = async () => {
    if (!uploadedImage) return;

    setIsProcessing(true);
    // Simulate AI processing with multiple variations
    setTimeout(() => {
      setProcessedImages([
        uploadedImage, // In production, these would be AI-transformed versions
        uploadedImage,
        uploadedImage,
      ]);
      toast.success('AI transformation complete! ✨');
      setIsProcessing(false);
    }, 3000);
  };

  const handleDownload = (imageUrl: string, index: number) => {
    toast.success(`Design ${index + 1} downloaded! 💾`);
  };

  const handleShare = (imageUrl: string, index: number) => {
    toast.success(`Design ${index + 1} link copied! 📋`);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        {/* Header */}
        <div className="text-center">
          <h3 className="text-4xl font-bold text-amber-400 mb-4" style={{ fontFamily: 'Bangers, cursive' }}>
            AI IMAGE TRANSFORMER
          </h3>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Upload any photo and watch our AI transform it into stunning neon graffiti art. 
            Get multiple variations powered by Gemini AI.
          </p>
        </div>

        {/* Upload Section */}
        <Card className="border border-amber-500/50 bg-black/80 p-8">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
          />

          {!uploadedImage ? (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full aspect-video bg-black/50 border border-cyan-500/50 hover:bg-cyan-500/5 transition-all flex flex-col items-center justify-center gap-4 cursor-pointer rounded"
            >
              <Upload className="w-20 h-20 text-cyan-400 animate-pulse" />
              <p className="text-2xl text-cyan-400" style={{ fontFamily: 'Bangers, cursive' }}>
                UPLOAD YOUR IMAGE
              </p>
              <p className="text-sm text-gray-400">JPG, PNG, or GIF • Max 10MB</p>
            </button>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-xl font-bold text-cyan-400 mb-3" style={{ fontFamily: 'Bangers, cursive' }}>
                    ORIGINAL
                  </h4>
                  <div className="aspect-square bg-black overflow-hidden border border-cyan-500/50 rounded">
                    <img src={uploadedImage} alt="Original" className="w-full h-full object-cover" />
                  </div>
                </div>

                <div>
                  <h4 className="text-xl font-bold text-emerald-400 mb-3" style={{ fontFamily: 'Bangers, cursive' }}>
                    PREVIEW
                  </h4>
                  <div className="aspect-square bg-black overflow-hidden border border-emerald-500/50 flex items-center justify-center rounded">
                    {isProcessing ? (
                      <div className="text-center">
                        <Loader2 className="w-16 h-16 animate-spin text-emerald-400 mx-auto mb-4" />
                        <p className="text-sm text-gray-400">AI is working its magic...</p>
                      </div>
                    ) : processedImages.length > 0 ? (
                      <img
                        src={processedImages[0]}
                        alt="Processed"
                        className="w-full h-full object-cover"
                        style={{
                          filter: 'saturate(2) contrast(1.3) brightness(1.2) hue-rotate(15deg)',
                        }}
                      />
                    ) : (
                      <p className="text-gray-500">Click transform to see results</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  variant="outline"
                  className="h-14 border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  <Upload className="w-5 h-5 mr-2" />
                  CHANGE IMAGE
                </Button>

                <Button
                  onClick={transformWithAI}
                  disabled={isProcessing}
                  className="h-14 border border-amber-500/50 bg-black hover:bg-amber-500/10 text-amber-400"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      TRANSFORMING...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      TRANSFORM WITH AI
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </Card>

        {/* Results Gallery */}
        {processedImages.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div>
              <h4 className="text-3xl font-bold text-fuchsia-400 mb-2" style={{ fontFamily: 'Bangers, cursive' }}>
                AI GENERATED VARIATIONS
              </h4>
              <p className="text-gray-400">Choose your favorite design and download or share</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {processedImages.map((img, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Card className="border border-fuchsia-500/50 bg-black/80 overflow-hidden group">
                    <div className="aspect-square overflow-hidden relative">
                      <img
                        src={img}
                        alt={`Variation ${i + 1}`}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        style={{
                          filter: `saturate(${1.5 + i * 0.3}) contrast(${1.2 + i * 0.1}) brightness(${1.1 + i * 0.05}) hue-rotate(${i * 30}deg)`,
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div className="p-4 space-y-3">
                      <h5 className="text-lg font-bold text-fuchsia-400" style={{ fontFamily: 'Bangers, cursive' }}>
                        VARIATION {i + 1}
                      </h5>
                      <div className="grid grid-cols-2 gap-2">
                        <Button
                          onClick={() => handleDownload(img, i)}
                          size="sm"
                          className="border border-emerald-500/50 bg-black hover:bg-emerald-500/10 text-emerald-400"
                        >
                          <Download className="w-4 h-4 mr-1" />
                          SAVE
                        </Button>
                        <Button
                          onClick={() => handleShare(img, i)}
                          size="sm"
                          className="border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400"
                        >
                          <Share2 className="w-4 h-4 mr-1" />
                          SHARE
                        </Button>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Features Info */}
        <Card className="border border-emerald-500/50 bg-black/80 p-8">
          <h4 className="text-2xl font-bold text-emerald-400 mb-4" style={{ fontFamily: 'Bangers, cursive' }}>
            HOW IT WORKS
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                step: '01',
                title: 'UPLOAD',
                description: 'Choose any photo from your device',
                color: 'cyan',
              },
              {
                step: '02',
                title: 'TRANSFORM',
                description: 'AI analyzes and applies neon graffiti effects',
                color: 'amber',
              },
              {
                step: '03',
                title: 'DOWNLOAD',
                description: 'Get multiple variations to choose from',
                color: 'fuchsia',
              },
            ].map((item, i) => (
              <div key={i} className="text-center">
                <div className={`text-6xl font-bold text-${item.color}-400 mb-2`} style={{ fontFamily: 'Bangers, cursive' }}>
                  {item.step}
                </div>
                <h5 className={`text-xl font-bold text-${item.color}-400 mb-2`} style={{ fontFamily: 'Bangers, cursive' }}>
                  {item.title}
                </h5>
                <p className="text-gray-400 text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
