import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import {
  User,
  Star,
  ShoppingBag,
  Image,
  Download,
  Trash2,
  RotateCcw,
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const mockSavedDesigns = [
  {
    id: 1,
    title: 'Neon Jacket Design',
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=400&q=80',
    date: '2024-01-15',
  },
  {
    id: 2,
    title: 'Graffiti Hoodie',
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&q=80',
    date: '2024-01-14',
  },
  {
    id: 3,
    title: 'Custom Keychain',
    image: 'https://images.unsplash.com/photo-1611858518726-829c65f30c0b?w=400&q=80',
    date: '2024-01-13',
  },
];

const mockOrders = [
  {
    id: 'ORD-001',
    item: 'Neon Graffiti Hoodie',
    price: 89.99,
    status: 'Delivered',
    date: '2024-01-10',
  },
  {
    id: 'ORD-002',
    item: 'Custom Jacket',
    price: 129.99,
    status: 'In Transit',
    date: '2024-01-12',
  },
  {
    id: 'ORD-003',
    item: 'Audio QR Keychain',
    price: 24.99,
    status: 'Processing',
    date: '2024-01-14',
  },
];

export default function ProfileSection() {
  const { user } = useAuth();

  return (
    <div className="max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        {/* Profile Card */}
        <Card className="border border-cyan-500/50 bg-black/80 p-8">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <Avatar className="w-32 h-32 border-2 border-fuchsia-500/50">
              <AvatarImage src={user?.avatar} />
              <AvatarFallback className="bg-black text-4xl text-fuchsia-400" style={{ fontFamily: 'Bangers, cursive' }}>
                {user?.displayName?.charAt(0) || user?.email?.charAt(0)}
              </AvatarFallback>
            </Avatar>

            <div className="flex-1 text-center md:text-left">
              <h3 className="text-4xl font-bold text-cyan-400 mb-2" style={{ fontFamily: 'Bangers, cursive' }}>
                {user?.displayName || user?.email?.split('@')[0]}
              </h3>
              <p className="text-gray-400 mb-4">{user?.email}</p>
              
              <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                <div className="border border-amber-500/50 bg-black px-6 py-3 rounded">
                  <div className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-amber-400" />
                    <span className="text-2xl font-bold text-amber-400">2,450</span>
                  </div>
                  <p className="text-xs text-gray-400 mt-1">Game Points</p>
                </div>

                <div className="border border-emerald-500/50 bg-black px-6 py-3 rounded">
                  <div className="flex items-center gap-2">
                    <ShoppingBag className="w-5 h-5 text-emerald-400" />
                    <span className="text-2xl font-bold text-emerald-400">{mockOrders.length}</span>
                  </div>
                  <p className="text-xs text-gray-400 mt-1">Orders</p>
                </div>

                <div className="border border-fuchsia-500/50 bg-black px-6 py-3 rounded">
                  <div className="flex items-center gap-2">
                    <Image className="w-5 h-5 text-fuchsia-400" />
                    <span className="text-2xl font-bold text-fuchsia-400">{mockSavedDesigns.length}</span>
                  </div>
                  <p className="text-xs text-gray-400 mt-1">Designs</p>
                </div>
              </div>
            </div>

            <Button className="border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400" style={{ fontFamily: 'Bangers, cursive' }}>
              <User className="w-4 h-4 mr-2" />
              EDIT PROFILE
            </Button>
          </div>
        </Card>

        {/* Saved Designs */}
        <div>
          <h4 className="text-3xl font-bold text-fuchsia-400 mb-6" style={{ fontFamily: 'Bangers, cursive' }}>
            SAVED DESIGNS
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {mockSavedDesigns.map((design, i) => (
              <motion.div
                key={design.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="border border-fuchsia-500/50 bg-black/80 overflow-hidden group">
                  <div className="aspect-square overflow-hidden relative">
                    <img
                      src={design.image}
                      alt={design.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="p-4">
                    <h5 className="font-bold text-fuchsia-400 mb-1" style={{ fontFamily: 'Bangers, cursive' }}>
                      {design.title}
                    </h5>
                    <p className="text-xs text-gray-400 mb-3">{design.date}</p>
                    <div className="grid grid-cols-2 gap-2">
                      <Button size="sm" className="border border-emerald-500/50 bg-black hover:bg-emerald-500/10 text-emerald-400">
                        <Download className="w-3 h-3 mr-1" />
                        SAVE
                      </Button>
                      <Button size="sm" variant="outline" className="border border-fuchsia-500/50 bg-black hover:bg-fuchsia-500/10 text-fuchsia-400">
                        <Trash2 className="w-3 h-3 mr-1" />
                        DELETE
                      </Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Order History */}
        <div>
          <h4 className="text-3xl font-bold text-emerald-400 mb-6" style={{ fontFamily: 'Bangers, cursive' }}>
            ORDER HISTORY
          </h4>
          <div className="space-y-4">
            {mockOrders.map((order, i) => (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="border border-emerald-500/50 bg-black/80 p-6">
                  <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div>
                      <h5 className="text-xl font-bold text-emerald-400 mb-1" style={{ fontFamily: 'Bangers, cursive' }}>
                        {order.item}
                      </h5>
                      <p className="text-sm text-gray-400">Order ID: {order.id} • {order.date}</p>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-2xl font-bold text-white">${order.price}</p>
                        <p className={`text-sm ${
                          order.status === 'Delivered' ? 'text-emerald-400' :
                          order.status === 'In Transit' ? 'text-cyan-400' :
                          'text-amber-400'
                        }`}>
                          {order.status}
                        </p>
                      </div>

                      <Button
                        size="sm"
                        className="border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400"
                        style={{ fontFamily: 'Bangers, cursive' }}
                      >
                        <RotateCcw className="w-4 h-4 mr-2" />
                        REORDER
                      </Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Account Settings */}
        <Card className="border border-amber-500/50 bg-black/80 p-8">
          <h4 className="text-2xl font-bold text-amber-400 mb-6" style={{ fontFamily: 'Bangers, cursive' }}>
            ACCOUNT SETTINGS
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button variant="outline" className="h-12 border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400 justify-start">
              Change Password
            </Button>
            <Button variant="outline" className="h-12 border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400 justify-start">
              Notification Settings
            </Button>
            <Button variant="outline" className="h-12 border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400 justify-start">
              Payment Methods
            </Button>
            <Button variant="outline" className="h-12 border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400 justify-start">
              Shipping Addresses
            </Button>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
