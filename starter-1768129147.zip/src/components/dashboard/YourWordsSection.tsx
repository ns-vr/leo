import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Video,
  Upload,
  Camera,
  Monitor,
  Users,
  MessageCircle,
  Play,
  Pause,
  Flame,
  Heart,
  ThumbsUp,
  Sparkles,
  Clock,
  Send,
  X,
  Link2,
  Copy,
  ShoppingCart,
  CreditCard,
  Check,
  Mic,
  MicOff,
  VideoOff,
} from 'lucide-react';
import { toast } from 'sonner';

interface Comment {
  id: string;
  user: string;
  text: string;
  timestamp: number | null;
  createdAt: Date;
}

interface Reaction {
  id: string;
  type: 'fire' | 'heart' | 'thumbsup' | 'sparkles';
  x: number;
  y: number;
}

interface WatchParty {
  id: string;
  title: string;
  host: string;
  viewers: number;
  isLive: boolean;
  thumbnail: string;
}

interface CartItem {
  id: string;
  title: string;
  price: number;
  type: 'watch-party' | 'recording';
}

const mockWatchParties: WatchParty[] = [
  {
    id: '1',
    title: 'STREET ART LIVE SESSION',
    host: 'NeonKing',
    viewers: 234,
    isLive: true,
    thumbnail: 'https://images.unsplash.com/photo-1561059488-916d69792237?w=600&q=70',
  },
  {
    id: '2',
    title: 'GRAFFITI DOCUMENTARY WATCH',
    host: 'UrbanQueen',
    viewers: 89,
    isLive: true,
    thumbnail: 'https://images.unsplash.com/photo-1569701813229-33284b643e3c?w=600&q=70',
  },
  {
    id: '3',
    title: 'MURAL PAINTING VOD',
    host: 'SprayMaster',
    viewers: 567,
    isLive: false,
    thumbnail: 'https://images.unsplash.com/photo-1499781350541-7783f6c6a0c8?w=600&q=70',
  },
];

export default function YourWordsSection() {
  const [activeSubTab, setActiveSubTab] = useState('watch');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingType, setRecordingType] = useState<'screen' | 'webcam' | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [addTimestamp, setAddTimestamp] = useState(false);
  const [reactions, setReactions] = useState<Reaction[]>([]);
  const [showPartyModal, setShowPartyModal] = useState(false);
  const [partyTitle, setPartyTitle] = useState('');
  const [inviteLink, setInviteLink] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCheckout, setShowCheckout] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const startScreenRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 30 },
        audio: true,
      });

      streamRef.current = stream;
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        setVideoUrl(url);
        setVideoFile(new File([blob], 'screen-recording.webm', { type: 'video/webm' }));
        stream.getTracks().forEach(track => track.stop());
      };

      stream.getVideoTracks()[0].onended = () => {
        stopRecording();
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingType('screen');
      toast.success('Screen recording started! 🎬');
    } catch (err) {
      toast.error('Failed to start screen recording');
    }
  };

  const startWebcamRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        setVideoUrl(url);
        setVideoFile(new File([blob], 'webcam-recording.webm', { type: 'video/webm' }));
        stream.getTracks().forEach(track => track.stop());
        if (videoRef.current) {
          videoRef.current.srcObject = null;
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingType('webcam');
      toast.success('Webcam recording started! 📹');
    } catch (err) {
      toast.error('Failed to access webcam');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
    setRecordingType(null);
    toast.success('Recording saved! ✨');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVideoFile(file);
      setVideoUrl(URL.createObjectURL(file));
      toast.success('Video uploaded! 🎥');
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const seekToTimestamp = (timestamp: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = timestamp;
      setIsPlaying(true);
      videoRef.current.play();
    }
  };

  const sendReaction = (type: Reaction['type']) => {
    const reaction: Reaction = {
      id: Date.now().toString(),
      type,
      x: Math.random() * 80 + 10,
      y: Math.random() * 60 + 20,
    };
    setReactions(prev => [...prev, reaction]);

    setTimeout(() => {
      setReactions(prev => prev.filter(r => r.id !== reaction.id));
    }, 2000);
  };

  const addComment = () => {
    if (!newComment.trim()) return;

    const comment: Comment = {
      id: Date.now().toString(),
      user: 'You',
      text: newComment,
      timestamp: addTimestamp ? currentTime : null,
      createdAt: new Date(),
    };

    setComments(prev => [...prev, comment]);
    setNewComment('');
    setAddTimestamp(false);
    toast.success('Comment added! 💬');
  };

  const createWatchParty = () => {
    if (!partyTitle.trim()) {
      toast.error('Please enter a party title');
      return;
    }

    const link = `https://leo.app/party/${Date.now().toString(36)}`;
    setInviteLink(link);
    toast.success('Watch party created! Share the link to invite friends 🎉');
  };

  const copyInviteLink = () => {
    navigator.clipboard.writeText(inviteLink);
    toast.success('Link copied! 📋');
  };

  const addToCart = (item: CartItem) => {
    setCart(prev => [...prev, item]);
    toast.success(`${item.title} added to cart! 🛒`);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const getTotalPrice = () => {
    return cart.reduce((sum, item) => sum + item.price, 0);
  };

  const processCheckout = () => {
    toast.success('Payment successful! Thank you for your purchase 🎉');
    setCart([]);
    setShowCheckout(false);
  };

  const getReactionIcon = (type: Reaction['type']) => {
    switch (type) {
      case 'fire': return <Flame className="w-6 h-6 text-orange-400" />;
      case 'heart': return <Heart className="w-6 h-6 text-red-400" />;
      case 'thumbsup': return <ThumbsUp className="w-6 h-6 text-cyan-400" />;
      case 'sparkles': return <Sparkles className="w-6 h-6 text-yellow-400" />;
    }
  };

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h3 className="text-3xl font-bold neon-glow-green mb-2" style={{ fontFamily: 'Bangers, cursive' }}>
          YOUR WORDS
        </h3>
        <p className="text-gray-400">Watch parties, live commentary, and share your voice</p>
      </motion.div>

      <Tabs value={activeSubTab} onValueChange={setActiveSubTab} className="w-full">
        <TabsList className="w-full grid grid-cols-3 bg-black/50 border border-cyan-500/30">
          <TabsTrigger value="watch" className="data-[state=active]:text-cyan-400 data-[state=active]:bg-black/70 data-[state=active]:border-b-2 data-[state=active]:border-cyan-400">
            <Users className="w-4 h-4 mr-2" />
            WATCH PARTIES
          </TabsTrigger>
          <TabsTrigger value="record" className="data-[state=active]:text-emerald-400 data-[state=active]:bg-black/70 data-[state=active]:border-b-2 data-[state=active]:border-emerald-400">
            <Video className="w-4 h-4 mr-2" />
            RECORD
          </TabsTrigger>
          <TabsTrigger value="upload" className="data-[state=active]:text-violet-400 data-[state=active]:bg-black/70 data-[state=active]:border-b-2 data-[state=active]:border-violet-400">
            <Upload className="w-4 h-4 mr-2" />
            UPLOAD
          </TabsTrigger>
        </TabsList>

        {/* Watch Parties Tab */}
        <TabsContent value="watch" className="mt-8">
          <div className="space-y-6">
            {/* Create Party Button */}
            <Button
              onClick={() => setShowPartyModal(true)}
              className="w-full border-2 border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400 py-6"
              style={{ fontFamily: 'Bangers, cursive' }}
            >
              <Users className="w-5 h-5 mr-2" />
              CREATE WATCH PARTY
            </Button>

            {/* Live Parties Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mockWatchParties.map((party, i) => (
                <motion.div
                  key={party.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                >
                  <Card className="border-2 border-cyan-500/30 bg-black/80 overflow-hidden group cursor-pointer">
                    <div className="aspect-video overflow-hidden relative">
                      <img
                        src={party.thumbnail}
                        alt={party.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                      {party.isLive && (
                        <span className="absolute top-3 left-3 px-3 py-1 bg-red-500/90 text-white text-xs font-bold rounded-sm animate-pulse">
                          LIVE
                        </span>
                      )}
                      <div className="absolute bottom-3 right-3 flex items-center gap-1 bg-black/70 px-2 py-1 rounded">
                        <Users className="w-4 h-4 text-cyan-400" />
                        <span className="text-white text-sm">{party.viewers}</span>
                      </div>
                    </div>
                    <div className="p-4">
                      <h4 className="text-lg font-bold text-cyan-400 mb-1" style={{ fontFamily: 'Bangers, cursive' }}>
                        {party.title}
                      </h4>
                      <p className="text-gray-400 text-sm mb-3">Hosted by {party.host}</p>
                      <div className="flex gap-2">
                        <Button
                          className="flex-1 border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400"
                          style={{ fontFamily: 'Bangers, cursive' }}
                        >
                          JOIN NOW
                        </Button>
                        <Button
                          onClick={() => addToCart({ id: party.id, title: party.title, price: 4.99, type: 'watch-party' })}
                          variant="ghost"
                          className="border border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10"
                        >
                          <ShoppingCart className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* Record Tab */}
        <TabsContent value="record" className="mt-8">
          <div className="space-y-6">
            {/* Recording Preview */}
            <Card className="border-2 border-emerald-500/30 bg-black/80 overflow-hidden">
              <div className="aspect-video bg-black relative flex items-center justify-center">
                {isRecording && recordingType === 'webcam' ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    muted
                    playsInline
                    className="w-full h-full object-cover"
                  />
                ) : videoUrl && !isRecording ? (
                  <video
                    ref={videoRef}
                    src={videoUrl}
                    className="w-full h-full object-cover"
                    onTimeUpdate={handleTimeUpdate}
                    onLoadedMetadata={handleLoadedMetadata}
                    onClick={() => {
                      if (videoRef.current) {
                        if (isPlaying) {
                          videoRef.current.pause();
                        } else {
                          videoRef.current.play();
                        }
                        setIsPlaying(!isPlaying);
                      }
                    }}
                  />
                ) : (
                  <div className="text-center p-8">
                    <Video className="w-16 h-16 text-emerald-400/50 mx-auto mb-4" />
                    <p className="text-gray-400">Start recording to preview</p>
                  </div>
                )}

                {/* Recording Indicator */}
                {isRecording && (
                  <div className="absolute top-4 left-4 flex items-center gap-2 bg-red-500/90 px-3 py-1 rounded">
                    <span className="w-3 h-3 bg-white rounded-full animate-pulse" />
                    <span className="text-white font-bold">REC</span>
                  </div>
                )}

                {/* Floating Reactions */}
                <AnimatePresence>
                  {reactions.map(reaction => (
                    <motion.div
                      key={reaction.id}
                      initial={{ opacity: 0, y: 20, scale: 0.5 }}
                      animate={{ opacity: 1, y: -100, scale: 1.2 }}
                      exit={{ opacity: 0 }}
                      className="absolute pointer-events-none"
                      style={{ left: `${reaction.x}%`, top: `${reaction.y}%` }}
                    >
                      {getReactionIcon(reaction.type)}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {/* Video Controls */}
              {videoUrl && !isRecording && (
                <div className="p-4 border-t border-emerald-500/20">
                  <div className="flex items-center gap-4 mb-3">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => {
                        if (videoRef.current) {
                          if (isPlaying) {
                            videoRef.current.pause();
                          } else {
                            videoRef.current.play();
                          }
                          setIsPlaying(!isPlaying);
                        }
                      }}
                      className="text-emerald-400"
                    >
                      {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                    </Button>
                    <div className="flex-1 h-1 bg-gray-700 rounded cursor-pointer"
                      onClick={(e) => {
                        const rect = e.currentTarget.getBoundingClientRect();
                        const percent = (e.clientX - rect.left) / rect.width;
                        if (videoRef.current) {
                          videoRef.current.currentTime = percent * duration;
                        }
                      }}
                    >
                      <div
                        className="h-full bg-emerald-400 rounded"
                        style={{ width: `${(currentTime / duration) * 100 || 0}%` }}
                      />
                    </div>
                    <span className="text-gray-400 text-sm font-mono">
                      {formatTime(currentTime)} / {formatTime(duration)}
                    </span>
                  </div>
                </div>
              )}
            </Card>

            {/* Recording Controls */}
            <div className="grid grid-cols-2 gap-4">
              <Button
                onClick={isRecording && recordingType === 'screen' ? stopRecording : startScreenRecording}
                disabled={isRecording && recordingType !== 'screen'}
                className={`py-8 border-2 ${isRecording && recordingType === 'screen' ? 'border-red-500 bg-red-500/10 text-red-400' : 'border-emerald-500/50 bg-black hover:bg-emerald-500/10 text-emerald-400'}`}
                style={{ fontFamily: 'Bangers, cursive' }}
              >
                <Monitor className="w-6 h-6 mr-3" />
                {isRecording && recordingType === 'screen' ? 'STOP RECORDING' : 'SCREEN CAPTURE'}
              </Button>

              <Button
                onClick={isRecording && recordingType === 'webcam' ? stopRecording : startWebcamRecording}
                disabled={isRecording && recordingType !== 'webcam'}
                className={`py-8 border-2 ${isRecording && recordingType === 'webcam' ? 'border-red-500 bg-red-500/10 text-red-400' : 'border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400'}`}
                style={{ fontFamily: 'Bangers, cursive' }}
              >
                <Camera className="w-6 h-6 mr-3" />
                {isRecording && recordingType === 'webcam' ? 'STOP RECORDING' : 'WEBCAM CAPTURE'}
              </Button>
            </div>

            {/* Webcam Controls */}
            {isRecording && recordingType === 'webcam' && (
              <div className="flex justify-center gap-4">
                <Button
                  onClick={() => setIsMuted(!isMuted)}
                  variant="ghost"
                  className={`border ${isMuted ? 'border-red-500 text-red-400' : 'border-gray-500 text-gray-400'}`}
                >
                  {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </Button>
                <Button
                  onClick={() => setIsCameraOff(!isCameraOff)}
                  variant="ghost"
                  className={`border ${isCameraOff ? 'border-red-500 text-red-400' : 'border-gray-500 text-gray-400'}`}
                >
                  {isCameraOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
                </Button>
              </div>
            )}

            {/* Reaction Buttons */}
            {(isRecording || videoUrl) && (
              <Card className="border border-gray-700 bg-black/50 p-4">
                <p className="text-gray-400 text-sm mb-3">Send reactions:</p>
                <div className="flex gap-3 justify-center">
                  <Button
                    onClick={() => sendReaction('fire')}
                    variant="ghost"
                    className="border border-orange-400/30 hover:bg-orange-400/10"
                  >
                    <Flame className="w-6 h-6 text-orange-400" />
                  </Button>
                  <Button
                    onClick={() => sendReaction('heart')}
                    variant="ghost"
                    className="border border-red-400/30 hover:bg-red-400/10"
                  >
                    <Heart className="w-6 h-6 text-red-400" />
                  </Button>
                  <Button
                    onClick={() => sendReaction('thumbsup')}
                    variant="ghost"
                    className="border border-cyan-400/30 hover:bg-cyan-400/10"
                  >
                    <ThumbsUp className="w-6 h-6 text-cyan-400" />
                  </Button>
                  <Button
                    onClick={() => sendReaction('sparkles')}
                    variant="ghost"
                    className="border border-yellow-400/30 hover:bg-yellow-400/10"
                  >
                    <Sparkles className="w-6 h-6 text-yellow-400" />
                  </Button>
                </div>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Upload Tab */}
        <TabsContent value="upload" className="mt-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Video Upload & Preview */}
            <div className="lg:col-span-2 space-y-6">
              {/* Upload Area */}
              <Card className="border-2 border-dashed border-violet-500/30 bg-black/80 p-8">
                <label className="flex flex-col items-center cursor-pointer">
                  <Upload className="w-16 h-16 text-violet-400/50 mb-4" />
                  <span className="text-violet-400 font-bold mb-2" style={{ fontFamily: 'Bangers, cursive' }}>
                    DROP VIDEO OR CLICK TO UPLOAD
                  </span>
                  <span className="text-gray-500 text-sm">MP4, WebM, MOV up to 500MB</span>
                  <input
                    type="file"
                    accept="video/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </Card>

              {/* Video Player */}
              {videoUrl && (
                <Card className="border-2 border-violet-500/30 bg-black/80 overflow-hidden">
                  <div className="aspect-video bg-black relative">
                    <video
                      ref={videoRef}
                      src={videoUrl}
                      className="w-full h-full object-contain"
                      onTimeUpdate={handleTimeUpdate}
                      onLoadedMetadata={handleLoadedMetadata}
                      onClick={() => {
                        if (videoRef.current) {
                          if (isPlaying) {
                            videoRef.current.pause();
                          } else {
                            videoRef.current.play();
                          }
                          setIsPlaying(!isPlaying);
                        }
                      }}
                    />

                    {/* Floating Reactions */}
                    <AnimatePresence>
                      {reactions.map(reaction => (
                        <motion.div
                          key={reaction.id}
                          initial={{ opacity: 0, y: 20, scale: 0.5 }}
                          animate={{ opacity: 1, y: -100, scale: 1.2 }}
                          exit={{ opacity: 0 }}
                          className="absolute pointer-events-none"
                          style={{ left: `${reaction.x}%`, top: `${reaction.y}%` }}
                        >
                          {getReactionIcon(reaction.type)}
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>

                  {/* Video Controls */}
                  <div className="p-4 border-t border-violet-500/20">
                    <div className="flex items-center gap-4 mb-3">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => {
                          if (videoRef.current) {
                            if (isPlaying) {
                              videoRef.current.pause();
                            } else {
                              videoRef.current.play();
                            }
                            setIsPlaying(!isPlaying);
                          }
                        }}
                        className="text-violet-400"
                      >
                        {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                      </Button>
                      <div className="flex-1 h-1 bg-gray-700 rounded cursor-pointer"
                        onClick={(e) => {
                          const rect = e.currentTarget.getBoundingClientRect();
                          const percent = (e.clientX - rect.left) / rect.width;
                          if (videoRef.current) {
                            videoRef.current.currentTime = percent * duration;
                          }
                        }}
                      >
                        <div
                          className="h-full bg-violet-400 rounded"
                          style={{ width: `${(currentTime / duration) * 100 || 0}%` }}
                        />
                      </div>
                      <span className="text-gray-400 text-sm font-mono">
                        {formatTime(currentTime)} / {formatTime(duration)}
                      </span>
                    </div>

                    {/* Reaction Buttons */}
                    <div className="flex gap-2 justify-center">
                      <Button
                        onClick={() => sendReaction('fire')}
                        size="sm"
                        variant="ghost"
                        className="border border-orange-400/30 hover:bg-orange-400/10"
                      >
                        <Flame className="w-4 h-4 text-orange-400" />
                      </Button>
                      <Button
                        onClick={() => sendReaction('heart')}
                        size="sm"
                        variant="ghost"
                        className="border border-red-400/30 hover:bg-red-400/10"
                      >
                        <Heart className="w-4 h-4 text-red-400" />
                      </Button>
                      <Button
                        onClick={() => sendReaction('thumbsup')}
                        size="sm"
                        variant="ghost"
                        className="border border-cyan-400/30 hover:bg-cyan-400/10"
                      >
                        <ThumbsUp className="w-4 h-4 text-cyan-400" />
                      </Button>
                      <Button
                        onClick={() => sendReaction('sparkles')}
                        size="sm"
                        variant="ghost"
                        className="border border-yellow-400/30 hover:bg-yellow-400/10"
                      >
                        <Sparkles className="w-4 h-4 text-yellow-400" />
                      </Button>
                    </div>
                  </div>
                </Card>
              )}

              {/* Start Party Button */}
              {videoUrl && (
                <Button
                  onClick={() => setShowPartyModal(true)}
                  className="w-full py-6 border-2 border-violet-500/50 bg-black hover:bg-violet-500/10 text-violet-400"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  <Users className="w-5 h-5 mr-2" />
                  START WATCH PARTY WITH THIS VIDEO
                </Button>
              )}
            </div>

            {/* Comments Section */}
            <div className="space-y-4">
              <Card className="border border-gray-700 bg-black/50 p-4">
                <h4 className="text-lg font-bold text-violet-400 mb-4" style={{ fontFamily: 'Bangers, cursive' }}>
                  <MessageCircle className="w-5 h-5 inline mr-2" />
                  COMMENTS
                </h4>

                {/* Comment Input */}
                <div className="space-y-3 mb-4">
                  <Textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Add your commentary..."
                    className="bg-black/50 border-gray-700 text-white resize-none"
                    rows={3}
                  />
                  <div className="flex items-center justify-between">
                    <Button
                      onClick={() => setAddTimestamp(!addTimestamp)}
                      variant="ghost"
                      size="sm"
                      className={`${addTimestamp ? 'text-violet-400 border-violet-400' : 'text-gray-400 border-gray-600'} border`}
                    >
                      <Clock className="w-4 h-4 mr-1" />
                      {addTimestamp ? formatTime(currentTime) : 'Add timestamp'}
                    </Button>
                    <Button
                      onClick={addComment}
                      size="sm"
                      className="border border-violet-500/50 bg-black hover:bg-violet-500/10 text-violet-400"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Comments List */}
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {comments.length === 0 ? (
                    <p className="text-gray-500 text-center py-4">No comments yet</p>
                  ) : (
                    comments.map(comment => (
                      <motion.div
                        key={comment.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="p-3 bg-black/50 border border-gray-700 rounded"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-violet-400 font-bold text-sm">{comment.user}</span>
                          {comment.timestamp !== null && (
                            <Button
                              onClick={() => seekToTimestamp(comment.timestamp!)}
                              variant="ghost"
                              size="sm"
                              className="text-cyan-400 text-xs h-auto py-1 px-2"
                            >
                              <Clock className="w-3 h-3 mr-1" />
                              {formatTime(comment.timestamp)}
                            </Button>
                          )}
                        </div>
                        <p className="text-gray-300 text-sm">{comment.text}</p>
                      </motion.div>
                    ))
                  )}
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Create Party Modal */}
      <AnimatePresence>
        {showPartyModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowPartyModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md"
              onClick={(e) => e.stopPropagation()}
            >
              <Card className="border-2 border-cyan-500/50 bg-black/95 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-cyan-400" style={{ fontFamily: 'Bangers, cursive' }}>
                    CREATE WATCH PARTY
                  </h3>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowPartyModal(false)}
                    className="text-gray-400"
                  >
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-gray-400 text-sm mb-2 block">Party Title</label>
                    <Input
                      value={partyTitle}
                      onChange={(e) => setPartyTitle(e.target.value)}
                      placeholder="Enter party title..."
                      className="bg-black/50 border-gray-700 text-white"
                    />
                  </div>

                  {inviteLink ? (
                    <div>
                      <label className="text-gray-400 text-sm mb-2 block">Invite Link</label>
                      <div className="flex gap-2">
                        <Input
                          value={inviteLink}
                          readOnly
                          className="bg-black/50 border-gray-700 text-cyan-400"
                        />
                        <Button
                          onClick={copyInviteLink}
                          variant="ghost"
                          className="border border-cyan-500/50 text-cyan-400"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <Button
                      onClick={createWatchParty}
                      className="w-full border-2 border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400 py-6"
                      style={{ fontFamily: 'Bangers, cursive' }}
                    >
                      <Link2 className="w-5 h-5 mr-2" />
                      GENERATE INVITE LINK
                    </Button>
                  )}

                  {inviteLink && (
                    <Button
                      onClick={() => {
                        setShowPartyModal(false);
                        toast.success('Watch party started! 🎉');
                      }}
                      className="w-full border-2 border-emerald-500/50 bg-black hover:bg-emerald-500/10 text-emerald-400 py-6"
                      style={{ fontFamily: 'Bangers, cursive' }}
                    >
                      <Play className="w-5 h-5 mr-2" />
                      START PARTY
                    </Button>
                  )}
                </div>
              </Card>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Checkout Modal */}
      <AnimatePresence>
        {showCheckout && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowCheckout(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md"
              onClick={(e) => e.stopPropagation()}
            >
              <Card className="border-2 border-emerald-500/50 bg-black/95 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-emerald-400" style={{ fontFamily: 'Bangers, cursive' }}>
                    CHECKOUT
                  </h3>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowCheckout(false)}
                    className="text-gray-400"
                  >
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                <div className="space-y-4 mb-6">
                  {cart.map(item => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-black/50 border border-gray-700 rounded">
                      <div>
                        <p className="text-white font-medium">{item.title}</p>
                        <p className="text-gray-400 text-sm">${item.price.toFixed(2)}</p>
                      </div>
                      <Button
                        onClick={() => removeFromCart(item.id)}
                        variant="ghost"
                        size="icon"
                        className="text-red-400"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>

                <div className="border-t border-gray-700 pt-4 mb-6">
                  <div className="flex justify-between text-lg">
                    <span className="text-gray-400">Total</span>
                    <span className="text-emerald-400 font-bold">${getTotalPrice().toFixed(2)}</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-gray-400 text-sm mb-2 block">Card Number</label>
                    <Input
                      placeholder="4242 4242 4242 4242"
                      className="bg-black/50 border-gray-700 text-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-gray-400 text-sm mb-2 block">Expiry</label>
                      <Input
                        placeholder="MM/YY"
                        className="bg-black/50 border-gray-700 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-gray-400 text-sm mb-2 block">CVC</label>
                      <Input
                        placeholder="123"
                        className="bg-black/50 border-gray-700 text-white"
                      />
                    </div>
                  </div>
                </div>

                <Button
                  onClick={processCheckout}
                  className="w-full mt-6 border-2 border-emerald-500/50 bg-black hover:bg-emerald-500/10 text-emerald-400 py-6"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  <CreditCard className="w-5 h-5 mr-2" />
                  PAY ${getTotalPrice().toFixed(2)}
                </Button>

                <p className="text-gray-500 text-xs text-center mt-4">
                  🔒 Test mode - Use card 4242 4242 4242 4242
                </p>
              </Card>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Cart Indicator */}
      {cart.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed bottom-20 md:bottom-8 right-8 border-2 border-emerald-500/50 bg-black/90 backdrop-blur-lg p-4 rounded-full shadow-2xl"
        >
          <Button
            onClick={() => setShowCheckout(true)}
            size="lg"
            className="border border-emerald-500/50 bg-black hover:bg-emerald-500/10 text-emerald-400 rounded-full h-16 w-16 relative"
          >
            <ShoppingCart className="w-6 h-6" />
            <span className="absolute -top-2 -right-2 bg-violet-500 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">
              {cart.length}
            </span>
          </Button>
        </motion.div>
      )}
    </div>
  );
}
