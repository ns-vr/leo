import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Upload, 
  Image as ImageIcon, 
  Shirt, 
  Tag, 
  Mic,
  QrCode,
  Download,
  Loader2 
} from 'lucide-react';
import { toast } from 'sonner';
import { QRCodeSVG } from 'qrcode.react';

export default function CustomSection() {
  const [activeProject, setActiveProject] = useState<'jacket' | 'keychain' | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [qrValue, setQrValue] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        toast.success('Image uploaded! 📸');
      };
      reader.readAsDataURL(file);
    }
  };

  const processWithAI = async () => {
    if (!uploadedImage) return;
    
    setIsProcessing(true);
    // Simulate AI processing
    setTimeout(() => {
      setProcessedImage(uploadedImage);
      toast.success('AI neonification complete! ✨');
      setIsProcessing(false);
    }, 2000);
  };

  const generateQRCode = () => {
    const mockAudioUrl = `https://leo-audio.storage/${Date.now()}.mp3`;
    setAudioUrl(mockAudioUrl);
    setQrValue(mockAudioUrl);
    toast.success('QR code generated! 📱');
  };

  const resetProject = () => {
    setActiveProject(null);
    setUploadedImage(null);
    setProcessedImage(null);
    setAudioUrl(null);
    setQrValue('');
  };

  if (!activeProject) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          whileHover={{ scale: 1.05 }}
          onClick={() => setActiveProject('jacket')}
        >
          <Card className="border border-emerald-500/50 bg-black/80 p-12 cursor-pointer hover:bg-emerald-500/5 transition-all h-full flex flex-col items-center justify-center text-center">
            <Shirt className="w-24 h-24 text-emerald-400 mb-6" />
            <h3 className="text-3xl font-bold text-emerald-400 mb-4" style={{ fontFamily: 'Bangers, cursive' }}>
              CUSTOM JACKET
            </h3>
            <p className="text-gray-300 mb-6">
              Upload your photo and transform it into a neon graffiti design with AI. 
              Perfect for unique hoodies and jackets.
            </p>
            <Button className="border border-emerald-500/50 bg-black hover:bg-emerald-500/10 text-emerald-400" style={{ fontFamily: 'Bangers, cursive' }}>
              START JACKET DESIGN
            </Button>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          whileHover={{ scale: 1.05 }}
          onClick={() => setActiveProject('keychain')}
        >
          <Card className="border border-fuchsia-500/50 bg-black/80 p-12 cursor-pointer hover:bg-fuchsia-500/5 transition-all h-full flex flex-col items-center justify-center text-center">
            <Tag className="w-24 h-24 text-fuchsia-400 mb-6" />
            <h3 className="text-3xl font-bold text-fuchsia-400 mb-4" style={{ fontFamily: 'Bangers, cursive' }}>
              CUSTOM KEYCHAIN
            </h3>
            <p className="text-gray-300 mb-6">
              Create an audio-enabled keychain with custom design and QR code. 
              Record a message and generate scannable link.
            </p>
            <Button className="border border-fuchsia-500/50 bg-black hover:bg-fuchsia-500/10 text-fuchsia-400" style={{ fontFamily: 'Bangers, cursive' }}>
              START KEYCHAIN DESIGN
            </Button>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h3 className={`text-4xl font-bold ${activeProject === 'jacket' ? 'text-emerald-400' : 'text-fuchsia-400'}`} style={{ fontFamily: 'Bangers, cursive' }}>
              {activeProject === 'jacket' ? 'CUSTOM JACKET DESIGN' : 'CUSTOM KEYCHAIN DESIGN'}
            </h3>
            <p className="text-gray-400 mt-2">Step-by-step creation process</p>
          </div>
          <Button onClick={resetProject} variant="ghost" className="text-gray-400 hover:text-white">
            Start Over
          </Button>
        </div>

        {/* Upload Step */}
        <Card className={`${activeProject === 'jacket' ? 'border border-emerald-500/50' : 'border border-fuchsia-500/50'} bg-black/80 p-8`}>
          <h4 className={`text-2xl font-bold ${activeProject === 'jacket' ? 'text-emerald-400' : 'text-fuchsia-400'} mb-4`} style={{ fontFamily: 'Bangers, cursive' }}>
            STEP 1: UPLOAD IMAGE
          </h4>
          
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
          />

          {!uploadedImage ? (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full aspect-video bg-black/50 border border-cyan-500/50 hover:bg-cyan-500/5 transition-all flex flex-col items-center justify-center gap-4 cursor-pointer rounded"
            >
              <Upload className="w-16 h-16 text-cyan-400" />
              <p className="text-xl text-cyan-400" style={{ fontFamily: 'Bangers, cursive' }}>
                CLICK TO UPLOAD
              </p>
              <p className="text-sm text-gray-400">JPG, PNG, or GIF (max 10MB)</p>
            </button>
          ) : (
            <div className="space-y-4">
              <div className="aspect-video bg-black overflow-hidden">
                <img src={uploadedImage} alt="Uploaded" className="w-full h-full object-contain" />
              </div>
              <Button
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
                className="w-full border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400"
              >
                <Upload className="w-4 h-4 mr-2" />
                Change Image
              </Button>
            </div>
          )}
        </Card>

        {/* AI Processing Step */}
        {uploadedImage && (
          <Card className={`${activeProject === 'jacket' ? 'border border-emerald-500/50' : 'border border-fuchsia-500/50'} bg-black/80 p-8`}>
            <h4 className={`text-2xl font-bold ${activeProject === 'jacket' ? 'text-emerald-400' : 'text-fuchsia-400'} mb-4`} style={{ fontFamily: 'Bangers, cursive' }}>
              STEP 2: AI NEONIFY
            </h4>
            
            {!processedImage ? (
              <Button
                onClick={processWithAI}
                disabled={isProcessing}
                className={`w-full h-16 text-xl ${activeProject === 'jacket' ? 'border border-emerald-500/50 text-emerald-400' : 'border border-fuchsia-500/50 text-fuchsia-400'} bg-black`}
                style={{ fontFamily: 'Bangers, cursive' }}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-6 h-6 mr-2 animate-spin" />
                    PROCESSING WITH AI...
                  </>
                ) : (
                  <>
                    <ImageIcon className="w-6 h-6 mr-2" />
                    TRANSFORM WITH AI
                  </>
                )}
              </Button>
            ) : (
              <div className="space-y-4">
                <div className="aspect-video bg-black overflow-hidden border border-amber-500/50 rounded">
                  <img src={processedImage} alt="Processed" className="w-full h-full object-contain" style={{ filter: 'saturate(2) contrast(1.2) brightness(1.1)' }} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Button
                    onClick={processWithAI}
                    variant="outline"
                    className="border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400"
                  >
                    Regenerate
                  </Button>
                  <Button
                    className="border border-emerald-500/50 bg-black hover:bg-emerald-500/10 text-emerald-400"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            )}
          </Card>
        )}

        {/* Keychain Specific Steps */}
        {activeProject === 'keychain' && processedImage && (
          <>
            <Card className="border border-fuchsia-500/50 bg-black/80 p-8">
              <h4 className="text-2xl font-bold text-fuchsia-400 mb-4" style={{ fontFamily: 'Bangers, cursive' }}>
                STEP 3: RECORD AUDIO MESSAGE
              </h4>
              
              <div className="space-y-4">
                <p className="text-gray-400">Record a custom audio message that plays when someone scans the QR code.</p>
                
                <Button
                  onClick={() => {
                    toast.success('Audio recording started! 🎤');
                    setTimeout(() => {
                      toast.success('Audio recorded! ✅');
                    }, 2000);
                  }}
                  className="w-full h-14 border border-fuchsia-500/50 text-fuchsia-400 bg-black"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  <Mic className="w-5 h-5 mr-2" />
                  START RECORDING
                </Button>
              </div>
            </Card>

            <Card className="border border-fuchsia-500/50 bg-black/80 p-8">
              <h4 className="text-2xl font-bold text-fuchsia-400 mb-4" style={{ fontFamily: 'Bangers, cursive' }}>
                STEP 4: GENERATE QR CODE
              </h4>
              
              {!qrValue ? (
                <Button
                  onClick={generateQRCode}
                  className="w-full h-14 border border-fuchsia-500/50 text-fuchsia-400 bg-black"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  <QrCode className="w-5 h-5 mr-2" />
                  GENERATE QR CODE
                </Button>
              ) : (
                <div className="space-y-4">
                  <div className="bg-white p-8 flex items-center justify-center">
                    <QRCodeSVG value={qrValue} size={256} />
                  </div>
                  <p className="text-sm text-gray-400 text-center">
                    Scan this QR code to play your audio message
                  </p>
                </div>
              )}
            </Card>
          </>
        )}

        {/* Final Step */}
        {processedImage && (activeProject === 'jacket' || qrValue) && (
          <Card className={`${activeProject === 'jacket' ? 'border border-emerald-500/50' : 'border border-fuchsia-500/50'} bg-black/80 p-8`}>
            <h4 className={`text-2xl font-bold ${activeProject === 'jacket' ? 'text-emerald-400' : 'text-fuchsia-400'} mb-4`} style={{ fontFamily: 'Bangers, cursive' }}>
              {activeProject === 'jacket' ? 'STEP 3' : 'STEP 5'}: PLACE ORDER
            </h4>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className={activeProject === 'jacket' ? 'text-emerald-400' : 'text-fuchsia-400'}>SIZE</Label>
                  <select className="w-full h-12 bg-black border border-gray-600 rounded px-4 text-white mt-2">
                    <option>Small</option>
                    <option>Medium</option>
                    <option>Large</option>
                    <option>XL</option>
                  </select>
                </div>
                <div>
                  <Label className={activeProject === 'jacket' ? 'text-emerald-400' : 'text-fuchsia-400'}>QUANTITY</Label>
                  <Input type="number" defaultValue={1} min={1} className="h-12 bg-black border border-gray-600 text-white mt-2" />
                </div>
              </div>

              <div>
                <Label className={activeProject === 'jacket' ? 'text-emerald-400' : 'text-fuchsia-400'}>SPECIAL INSTRUCTIONS</Label>
                <Textarea 
                  placeholder="Any special requests?" 
                  className="bg-black border border-gray-600 text-white mt-2 min-h-24"
                />
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-gray-700">
                <div>
                  <p className="text-gray-400">Total Price</p>
                  <p className="text-3xl font-bold text-amber-400">$149.99</p>
                </div>
                <Button
                  size="lg"
                  className={`h-14 px-8 text-xl ${activeProject === 'jacket' ? 'border border-emerald-500/50 text-emerald-400' : 'border border-fuchsia-500/50 text-fuchsia-400'} bg-black`}
                  style={{ fontFamily: 'Bangers, cursive' }}
                  onClick={() => toast.success('Order placed! 🎉')}
                >
                  CHECKOUT
                </Button>
              </div>
            </div>
          </Card>
        )}
      </motion.div>
    </div>
  );
}
