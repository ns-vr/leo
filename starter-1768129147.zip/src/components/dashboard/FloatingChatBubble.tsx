import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, Send, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

const mockAIResponses = [
  "Yo! What's good? Need help designing some fire merch? 🔥",
  "I can help you transform photos into neon art, create custom designs, or find the perfect playlist! 🎨",
  "That's dope! Upload your image and let's make some street magic happen! ✨",
  "Check out the AI Tools tab - that's where the transformation happens! 🎯",
  "Need some inspo? Hit up the Merch section to see what's trending! 👕",
];

export default function FloatingChatBubble() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hey! I'm your Leo AI assistant. What are you trying to create today? 🎨",
      sender: 'ai',
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');

  const sendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: inputValue,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages([...messages, userMessage]);
    setInputValue('');

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: messages.length + 2,
        text: mockAIResponses[Math.floor(Math.random() * mockAIResponses.length)],
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiMessage]);
    }, 1000);
  };

  return (
    <>
      {/* Floating Bubble */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-20 md:bottom-8 right-8 z-50 w-16 h-16 rounded-full border border-fuchsia-500/50 bg-black shadow-2xl flex items-center justify-center group"
          >
            <MessageCircle className="w-8 h-8 text-fuchsia-400 group-hover:scale-110 transition-transform" />
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full animate-pulse" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-20 md:bottom-8 right-8 z-50 w-full max-w-md mx-4 md:mx-0"
          >
            <div className="border border-fuchsia-500/50 bg-[#0A0A0A] backdrop-blur-lg rounded-lg overflow-hidden shadow-2xl">
              {/* Header */}
              <div className="bg-black/90 p-4 flex items-center justify-between border-b border-fuchsia-500/50">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Sparkles className="w-8 h-8 text-fuchsia-400" />
                    <span className="absolute -bottom-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-black" />
                  </div>
                  <div>
                    <h3 className="font-bold text-fuchsia-400" style={{ fontFamily: 'Bangers, cursive' }}>
                      LEO AI ASSISTANT
                    </h3>
                    <p className="text-xs text-gray-400">Always online</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Messages */}
              <ScrollArea className="h-96 p-4 spray-paint-texture">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[80%] p-3 rounded-lg ${
                          message.sender === 'user'
                            ? 'border border-cyan-500/50 bg-black/80 text-cyan-400'
                            : 'border border-fuchsia-500/50 bg-black/80 text-white'
                        }`}
                      >
                        <p className="text-sm">{message.text}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </ScrollArea>

              {/* Input */}
              <div className="p-4 border-t border-fuchsia-500/50 bg-black/90">
                <div className="flex gap-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                    placeholder="Ask me anything..."
                    className="flex-1 h-12 bg-black/50 text-white border border-cyan-500/50 focus:bg-black/70"
                  />
                  <Button
                    onClick={sendMessage}
                    disabled={!inputValue.trim()}
                    size="icon"
                    className="h-12 w-12 border border-fuchsia-500/50 bg-black hover:bg-fuchsia-500/10 text-fuchsia-400"
                  >
                    <Send className="w-5 h-5" />
                  </Button>
                </div>

                {/* Quick Actions */}
                <div className="flex flex-wrap gap-2 mt-3">
                  {[
                    '🎨 Design help',
                    '👕 Browse merch',
                    '🎵 Playlists',
                  ].map((action) => (
                    <button
                      key={action}
                      onClick={() => setInputValue(action)}
                      className="text-xs px-3 py-1 border border-amber-500/50 bg-black hover:bg-amber-500/10 text-amber-400 transition-colors rounded"
                    >
                      {action}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
