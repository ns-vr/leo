import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Mail, Lock, ArrowLeft } from 'lucide-react';

export default function AuthScreen() {
  const navigate = useNavigate();
  const { login, signup, resetPassword } = useAuth();
  const [loading, setLoading] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const [resetEmail, setResetEmail] = useState('');

  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [signupData, setSignupData] = useState({ email: '', password: '', confirmPassword: '' });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(loginData.email, loginData.password);
      toast.success('Welcome back! 🎨');
      navigate('/dashboard');
    } catch (error: any) {
      toast.error(error.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (signupData.password !== signupData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    setLoading(true);
    try {
      await signup(signupData.email, signupData.password);
      toast.success('Account created! Welcome to LEO 🚀');
      navigate('/dashboard');
    } catch (error: any) {
      toast.error(error.message || 'Signup failed');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await resetPassword(resetEmail);
      toast.success('Password reset email sent! Check your inbox 📧');
      setShowReset(false);
      setResetEmail('');
    } catch (error: any) {
      toast.error(error.message || 'Reset failed');
    } finally {
      setLoading(false);
    }
  };

  if (showReset) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] brick-texture flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md"
        >
          <div className="border border-amber-500/50 bg-black/90 backdrop-blur-lg p-8 rounded-lg">
            <button
              onClick={() => setShowReset(false)}
              className="mb-6 flex items-center gap-2 text-amber-400 hover:opacity-70 transition-opacity"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to login</span>
            </button>

            <h2 className="text-4xl font-bold text-amber-400 mb-2" style={{ fontFamily: 'Bangers, cursive' }}>
              RESET PASSWORD
            </h2>
            <p className="text-gray-400 mb-6">Enter your email to receive a reset link</p>

            <form onSubmit={handleResetPassword} className="space-y-6">
              <div>
                <Label htmlFor="reset-email" className="text-amber-400">EMAIL</Label>
                <div className="relative mt-2">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-amber-400" />
                  <Input
                    id="reset-email"
                    type="email"
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    required
                    className="pl-12 h-12 border border-amber-500/50 bg-black/50 text-white focus:bg-black/70"
                    placeholder="your@email.com"
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full h-12 text-lg font-bold border border-amber-500/50 bg-black hover:bg-amber-500/10 text-amber-400"
                style={{ fontFamily: 'Bangers, cursive' }}
              >
                {loading ? 'SENDING...' : 'SEND RESET LINK'}
              </Button>
            </form>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] brick-texture flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="mb-8 text-center">
          <h1 className="text-6xl font-bold text-emerald-400 mb-2" style={{ fontFamily: 'Bangers, cursive' }}>
            LEO
          </h1>
          <p className="text-gray-400">Join the street art revolution</p>
        </div>

        <Tabs defaultValue="login" className="w-full">
          <TabsList className="grid w-full grid-cols-2 border border-emerald-500/50 bg-black/50 mb-6 rounded-lg">
            <TabsTrigger value="login" className="data-[state=active]:text-emerald-400 data-[state=active]:bg-black/70">
              LOGIN
            </TabsTrigger>
            <TabsTrigger value="signup" className="data-[state=active]:text-emerald-400 data-[state=active]:bg-black/70">
              SIGN UP
            </TabsTrigger>
          </TabsList>

          <TabsContent value="login">
            <div className="border border-emerald-500/50 bg-black/90 backdrop-blur-lg p-8 rounded-lg">
              <form onSubmit={handleLogin} className="space-y-6">
                <div>
                  <Label htmlFor="login-email" className="text-emerald-400">EMAIL</Label>
                  <div className="relative mt-2">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-400" />
                    <Input
                      id="login-email"
                      type="email"
                      value={loginData.email}
                      onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                      required
                      className="pl-12 h-12 border border-emerald-500/50 bg-black/50 text-white focus:bg-black/70"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="login-password" className="text-emerald-400">PASSWORD</Label>
                  <div className="relative mt-2">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-400" />
                    <Input
                      id="login-password"
                      type="password"
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      required
                      minLength={6}
                      className="pl-12 h-12 border border-emerald-500/50 bg-black/50 text-white focus:bg-black/70"
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowReset(true)}
                  className="text-sm text-cyan-400 hover:opacity-70 transition-opacity"
                >
                  Forgot password?
                </button>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full h-12 text-lg font-bold border border-emerald-500/50 bg-black hover:bg-emerald-500/10 text-emerald-400"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  {loading ? 'LOGGING IN...' : 'LOGIN'}
                </Button>
              </form>
            </div>
          </TabsContent>

          <TabsContent value="signup">
            <div className="border border-cyan-500/50 bg-black/90 backdrop-blur-lg p-8 rounded-lg">
              <form onSubmit={handleSignup} className="space-y-6">
                <div>
                  <Label htmlFor="signup-email" className="text-cyan-400">EMAIL</Label>
                  <div className="relative mt-2">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-cyan-400" />
                    <Input
                      id="signup-email"
                      type="email"
                      value={signupData.email}
                      onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                      required
                      className="pl-12 h-12 border border-cyan-500/50 bg-black/50 text-white focus:bg-black/70"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="signup-password" className="text-cyan-400">PASSWORD</Label>
                  <div className="relative mt-2">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-cyan-400" />
                    <Input
                      id="signup-password"
                      type="password"
                      value={signupData.password}
                      onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                      required
                      minLength={6}
                      className="pl-12 h-12 border border-cyan-500/50 bg-black/50 text-white focus:bg-black/70"
                      placeholder="Min. 6 characters"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="signup-confirm" className="text-cyan-400">CONFIRM PASSWORD</Label>
                  <div className="relative mt-2">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-cyan-400" />
                    <Input
                      id="signup-confirm"
                      type="password"
                      value={signupData.confirmPassword}
                      onChange={(e) => setSignupData({ ...signupData, confirmPassword: e.target.value })}
                      required
                      minLength={6}
                      className="pl-12 h-12 border border-cyan-500/50 bg-black/50 text-white focus:bg-black/70"
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full h-12 text-lg font-bold border border-cyan-500/50 bg-black hover:bg-cyan-500/10 text-cyan-400"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  {loading ? 'CREATING ACCOUNT...' : 'SIGN UP'}
                </Button>
              </form>
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-6 text-center">
          <Button
            onClick={() => navigate('/home')}
            variant="ghost"
            className="text-gray-400 hover:text-white"
          >
            Continue as guest
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
