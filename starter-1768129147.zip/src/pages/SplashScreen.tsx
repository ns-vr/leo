import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ShoppingBag, Sparkles, Music, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useEffect, useState } from 'react';

export default function SplashScreen() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowContent(true);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (showContent && user) {
      navigate('/dashboard');
    }
  }, [showContent, user, navigate]);

  return (
    <div className="min-h-screen bg-[#0A0A0A] relative overflow-hidden spray-paint-texture">
      {/* Animated background particles */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-emerald-500 rounded-full opacity-30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6">
        {/* Logo Animation */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ duration: 1, ease: 'easeOut' }}
          className="mb-8"
        >
          <h1 
            className="text-8xl md:text-9xl font-bold neon-glow-green glitch"
            data-text="LEO"
            style={{ fontFamily: 'Bangers, cursive' }}
          >
            LEO
          </h1>
        </motion.div>

        {/* Tagline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="mb-12 text-center"
        >
          <p className="text-xl md:text-2xl text-cyan-400 mb-2">
            STREET ART MERCH EMPIRE
          </p>
          <p className="text-sm md:text-base text-gray-400">
            Design. Create. Vibe. Own the Streets.
          </p>
        </motion.div>

        {/* Feature Icons */}
        {showContent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12 w-full max-w-2xl"
          >
            {[
              { icon: ShoppingBag, label: 'MERCH', color: 'green' },
              { icon: Sparkles, label: 'AI TOOLS', color: 'pink' },
              { icon: Music, label: 'PLAYLISTS', color: 'yellow' },
              { icon: MessageCircle, label: 'CHAT', color: 'blue' },
            ].map((item, i) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + i * 0.1 }}
                className={`flex flex-col items-center gap-2 p-4 neon-box-${item.color} bg-black/50 backdrop-blur-sm`}
              >
                <item.icon className={`w-8 h-8 neon-glow-${item.color}`} />
                <span className={`text-xs neon-glow-${item.color}`}>{item.label}</span>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* CTA Buttons */}
        {showContent && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2 }}
            className="flex flex-col sm:flex-row gap-4 w-full max-w-md"
          >
            <Button
              onClick={() => navigate('/home')}
              className="flex-1 h-14 text-lg font-bold border border-emerald-500/60 bg-black hover:bg-emerald-500/10 text-emerald-400 transition-all duration-300 hover:scale-105"
              style={{ fontFamily: 'Bangers, cursive' }}
            >
              EXPLORE
            </Button>
            <Button
              onClick={() => navigate('/auth')}
              className="flex-1 h-14 text-lg font-bold border border-cyan-500/60 bg-black hover:bg-cyan-500/10 text-cyan-400 transition-all duration-300 hover:scale-105"
              style={{ fontFamily: 'Bangers, cursive' }}
            >
              GET STARTED
            </Button>
          </motion.div>
        )}

        {/* Bottom tagline */}
        {showContent && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
            className="mt-12 text-sm text-gray-500 text-center"
          >
            Powered by AI • Gen Z Culture • Underground Vibes
          </motion.p>
        )}
      </div>

      {/* Corner decorations */}
      <div className="absolute top-4 left-4 w-20 h-20 border-l-2 border-t-2 border-fuchsia-500/40" />
      <div className="absolute top-4 right-4 w-20 h-20 border-r-2 border-t-2 border-cyan-500/40" />
      <div className="absolute bottom-4 left-4 w-20 h-20 border-l-2 border-b-2 border-amber-500/40" />
      <div className="absolute bottom-4 right-4 w-20 h-20 border-r-2 border-b-2 border-emerald-500/40" />
    </div>
  );
}
