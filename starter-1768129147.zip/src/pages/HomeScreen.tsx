import { useState, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { 
  ShoppingBag, 
  Sparkles, 
  Music, 
  Zap,
  Star,
  Heart,
  Target
} from 'lucide-react';
import { toast } from 'sonner';

const floatingStickers = [
  { icon: Star, color: '#10B981', x: 10, y: 20 },
  { icon: Heart, color: '#D946EF', x: 80, y: 30 },
  { icon: Zap, color: '#06B6D4', x: 20, y: 60 },
  { icon: Target, color: '#EAB308', x: 85, y: 70 },
  { icon: Sparkles, color: '#10B981', x: 50, y: 40 },
  { icon: ShoppingBag, color: '#D946EF', x: 70, y: 15 },
];

export default function HomeScreen() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { scrollY } = useScroll();
  const [gamePoints, setGamePoints] = useState(0);

  const y1 = useTransform(scrollY, [0, 300], [0, -50]);
  const y2 = useTransform(scrollY, [0, 300], [0, -100]);
  const y3 = useTransform(scrollY, [0, 300], [0, -150]);

  const handleStickerTap = (color: string) => {
    setGamePoints(prev => prev + 10);
    toast.success('+10 Points! 🎨', {
      style: {
        background: '#0A0A0A',
        color: color,
        border: `1px solid ${color}`,
      },
    });
  };

  useEffect(() => {
    const handleShake = (e: DeviceMotionEvent) => {
      const acceleration = e.accelerationIncludingGravity;
      if (acceleration) {
        const total = Math.abs(acceleration.x || 0) + 
                     Math.abs(acceleration.y || 0) + 
                     Math.abs(acceleration.z || 0);
        
        if (total > 30) {
          setGamePoints(prev => prev + 25);
          toast.success('+25 Points! Shake it! 🎉', {
            style: {
              background: '#0A0A0A',
              color: '#10B981',
              border: '1px solid #10B981',
            },
          });
        }
      }
    };

    window.addEventListener('devicemotion', handleShake as any);
    return () => window.removeEventListener('devicemotion', handleShake as any);
  }, []);

  return (
    <div className="min-h-screen bg-[#0A0A0A] relative overflow-hidden">
      {/* Parallax Background Layers */}
      <motion.div style={{ y: y1 }} className="absolute inset-0 spray-paint-texture opacity-20" />
      <motion.div style={{ y: y2 }} className="absolute inset-0">
        {floatingStickers.map((sticker, i) => (
          <motion.button
            key={i}
            onClick={() => handleStickerTap(sticker.color)}
            className="absolute animate-float cursor-pointer transition-transform hover:scale-125"
            style={{
              left: `${sticker.x}%`,
              top: `${sticker.y}%`,
              color: sticker.color,
            }}
            animate={{
              y: [0, -20, 0],
              rotate: [0, 10, -10, 0],
            }}
            transition={{
              duration: 4 + i,
              repeat: Infinity,
              delay: i * 0.5,
            }}
          >
            <sticker.icon className="w-12 h-12 md:w-16 md:h-16" style={{ filter: `drop-shadow(0 0 10px ${sticker.color})` }} />
          </motion.button>
        ))}
      </motion.div>

      {/* Main Content */}
      <div className="relative z-10">
        {/* Header */}
        <header className="sticky top-0 z-50 backdrop-blur-md bg-black/50 border-b border-emerald-500/60">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <h1 className="text-3xl md:text-4xl font-bold neon-glow-green" style={{ fontFamily: 'Bangers, cursive' }}>
              LEO
            </h1>
            
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center gap-2 border border-amber-500/60 px-4 py-2 bg-black/70 rounded">
                <Star className="w-5 h-5 text-amber-400" />
                <span className="text-amber-400 font-bold">{gamePoints}</span>
              </div>
              
              {user ? (
                <Button
                  onClick={() => navigate('/dashboard')}
                  className="border border-emerald-500/60 bg-black hover:bg-emerald-500/10 text-emerald-400"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  DASHBOARD
                </Button>
              ) : (
                <Button
                  onClick={() => navigate('/auth')}
                  className="border border-emerald-500/60 bg-black hover:bg-emerald-500/10 text-emerald-400"
                  style={{ fontFamily: 'Bangers, cursive' }}
                >
                  LOGIN
                </Button>
              )}
            </div>
          </div>
        </header>

        {/* Hero Section */}
        <motion.section
          style={{ y: y3 }}
          className="container mx-auto px-4 py-16 md:py-24 text-center"
        >
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl lg:text-8xl font-bold neon-glow-pink mb-6 glitch"
            data-text="STREET ART"
            style={{ fontFamily: 'Bangers, cursive' }}
          >
            STREET ART
          </motion.h2>
          
          <motion.h3
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold neon-glow-blue mb-8"
            style={{ fontFamily: 'Bangers, cursive' }}
          >
            GOES DIGITAL
          </motion.h3>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-lg md:text-xl text-gray-300 mb-12 max-w-2xl mx-auto"
          >
            Transform your photos into neon masterpieces. Design custom merch with AI. 
            Vibe with curated street playlists. Join the underground revolution.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button
              onClick={() => navigate(user ? '/dashboard' : '/auth')}
              size="lg"
              className="h-16 px-8 text-xl font-bold border-2 border-emerald-500/60 bg-black hover:bg-emerald-500/10 text-emerald-400 transition-all duration-300 hover:scale-105"
              style={{ fontFamily: 'Bangers, cursive' }}
            >
              <Sparkles className="w-6 h-6 mr-2" />
              START CREATING
            </Button>
            
            <Button
              onClick={() => navigate('/dashboard/merch')}
              size="lg"
              variant="outline"
              className="h-16 px-8 text-xl font-bold border-2 border-cyan-500/60 bg-black hover:bg-cyan-500/10 text-cyan-400"
              style={{ fontFamily: 'Bangers, cursive' }}
            >
              <ShoppingBag className="w-6 h-6 mr-2" />
              SHOP MERCH
            </Button>
          </motion.div>
        </motion.section>

        {/* Featured Products Carousel */}
        <section className="container mx-auto px-4 py-16">
          <h3 className="text-4xl font-bold text-amber-400 mb-8 text-center" style={{ fontFamily: 'Bangers, cursive' }}>
            FEATURED DROPS
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: 'NEON GRAFFITI HOODIE',
                price: '$89.99',
                image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800&q=80',
                color: 'green',
              },
              {
                title: 'AI CUSTOM JACKET',
                price: '$129.99',
                image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&q=80',
                color: 'pink',
              },
              {
                title: 'AUDIO QR KEYCHAIN',
                price: '$24.99',
                image: 'https://images.unsplash.com/photo-1611858518726-829c65f30c0b?w=800&q=80',
                color: 'blue',
              },
            ].map((product, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05 }}
                className={`neon-box-${product.color} bg-black/80 backdrop-blur-sm overflow-hidden group cursor-pointer`}
                onClick={() => navigate('/dashboard/merch')}
              >
                <div className="aspect-square overflow-hidden relative">
                  <img
                    src={product.image}
                    alt={product.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                </div>
                <div className="p-6">
                  <h4 className={`text-2xl font-bold neon-glow-${product.color} mb-2`} style={{ fontFamily: 'Bangers, cursive' }}>
                    {product.title}
                  </h4>
                  <p className="text-3xl font-bold text-white">{product.price}</p>
                  <Button
                    className={`w-full mt-4 neon-box-${product.color} bg-black hover:bg-white/10`}
                    style={{ fontFamily: 'Bangers, cursive' }}
                  >
                    BUY NOW
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Features Grid */}
        <section className="container mx-auto px-4 py-16">
          <h3 className="text-4xl font-bold text-emerald-400 mb-12 text-center" style={{ fontFamily: 'Bangers, cursive' }}>
            WHAT YOU GET
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Sparkles,
                title: 'AI DESIGN TOOLS',
                description: 'Transform photos into neon graffiti art with Gemini AI',
                color: 'pink',
              },
              {
                icon: ShoppingBag,
                title: 'CUSTOM MERCH',
                description: 'Hoodies, jackets, keychains with your designs',
                color: 'green',
              },
              {
                icon: Music,
                title: 'CURATED PLAYLISTS',
                description: 'Underground hype music to match the vibe',
                color: 'yellow',
              },
              {
                icon: Zap,
                title: 'INSTANT CHECKOUT',
                description: 'Secure payments with Stripe integration',
                color: 'blue',
              },
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className={`neon-box-${feature.color} bg-black/80 backdrop-blur-sm p-6 text-center hover:scale-105 transition-transform`}
              >
                <feature.icon className={`w-16 h-16 mx-auto mb-4 neon-glow-${feature.color}`} />
                <h4 className={`text-xl font-bold neon-glow-${feature.color} mb-2`} style={{ fontFamily: 'Bangers, cursive' }}>
                  {feature.title}
                </h4>
                <p className="text-gray-400 text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="container mx-auto px-4 py-16 mb-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="border-2 border-emerald-500/60 bg-black/90 backdrop-blur-lg p-12 text-center rounded-lg"
          >
            <h3 className="text-5xl md:text-6xl font-bold text-emerald-400 mb-6" style={{ fontFamily: 'Bangers, cursive' }}>
              READY TO CREATE?
            </h3>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Join thousands of creators designing street art merch with AI. 
              Start your journey now.
            </p>
            <Button
              onClick={() => navigate(user ? '/dashboard' : '/auth')}
              size="lg"
              className="h-16 px-12 text-2xl font-bold border-2 border-fuchsia-500/60 bg-black hover:bg-fuchsia-500/10 text-fuchsia-400 transition-all duration-300 hover:scale-105"
              style={{ fontFamily: 'Bangers, cursive' }}
            >
              {user ? 'GO TO DASHBOARD' : 'GET STARTED FREE'}
            </Button>
          </motion.div>
        </section>
      </div>
    </div>
  );
}
