import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import {
  Home,
  ShoppingBag,
  Palette,
  Sparkles,
  User,
  MessageCircle,
  LogOut,
  Video,
} from 'lucide-react';
import MerchSection from '@/components/dashboard/MerchSection';
import CustomSection from '@/components/dashboard/CustomSection';
import AIToolsSection from '@/components/dashboard/AIToolsSection';
import ProfileSection from '@/components/dashboard/ProfileSection';
import FloatingChatBubble from '@/components/dashboard/FloatingChatBubble';
import YourWordsSection from '@/components/dashboard/YourWordsSection';
import { toast } from 'sonner';

export default function Dashboard() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('merch');

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out successfully');
    navigate('/');
  };

  if (!user) {
    navigate('/auth');
    return null;
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] spray-paint-texture">
      {/* Top Navigation */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-black/80 border-b border-emerald-500/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate('/home')}
              className="flex items-center gap-2"
            >
              <h1 className="text-3xl md:text-4xl font-bold neon-glow-green" style={{ fontFamily: 'Bangers, cursive' }}>
                LEO
              </h1>
            </button>

            <div className="flex items-center gap-4">
              <div className="hidden md:flex items-center gap-2 border border-cyan-500/50 px-4 py-2 bg-black/70 rounded">
                <User className="w-5 h-5 text-cyan-400" />
                <span className="text-cyan-400 font-medium">{user.displayName || user.email}</span>
              </div>

              <Button
                onClick={handleLogout}
                variant="ghost"
                size="icon"
                className="text-gray-400 hover:text-fuchsia-400 hover:bg-fuchsia-500/10"
              >
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-fuchsia-400 mb-2" style={{ fontFamily: 'Bangers, cursive' }}>
            CREATOR DASHBOARD
          </h2>
          <p className="text-gray-400">Design, customize, and shop all in one place</p>
        </motion.div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          {/* Tab Navigation */}
          <TabsList className="w-full grid grid-cols-5 gap-2 bg-transparent mb-8 h-auto">
            <TabsTrigger
              value="merch"
              className="border border-emerald-500/50 bg-black/80 data-[state=active]:bg-emerald-500/15 data-[state=active]:text-emerald-400 h-20 flex flex-col gap-2"
            >
              <ShoppingBag className="w-6 h-6" />
              <span className="text-xs md:text-sm font-bold">MERCH</span>
            </TabsTrigger>

            <TabsTrigger
              value="your-words"
              className="border border-cyan-500/50 bg-black/80 data-[state=active]:bg-cyan-500/15 data-[state=active]:text-cyan-400 h-20 flex flex-col gap-2"
            >
              <Video className="w-6 h-6" />
              <span className="text-xs md:text-sm font-bold">YOUR WORDS</span>
            </TabsTrigger>

            <TabsTrigger
              value="custom"
              className="border border-fuchsia-500/50 bg-black/80 data-[state=active]:bg-fuchsia-500/15 data-[state=active]:text-fuchsia-400 h-20 flex flex-col gap-2"
            >
              <Palette className="w-6 h-6" />
              <span className="text-xs md:text-sm font-bold">CUSTOM</span>
            </TabsTrigger>

            <TabsTrigger
              value="ai-tools"
              className="border border-amber-500/50 bg-black/80 data-[state=active]:bg-amber-500/15 data-[state=active]:text-amber-400 h-20 flex flex-col gap-2"
            >
              <Sparkles className="w-6 h-6" />
              <span className="text-xs md:text-sm font-bold">AI TOOLS</span>
            </TabsTrigger>

            <TabsTrigger
              value="profile"
              className="border border-cyan-500/50 bg-black/80 data-[state=active]:bg-cyan-500/15 data-[state=active]:text-cyan-400 h-20 flex flex-col gap-2"
            >
              <User className="w-6 h-6" />
              <span className="text-xs md:text-sm font-bold">PROFILE</span>
            </TabsTrigger>
          </TabsList>

          {/* Tab Content */}
          <TabsContent value="merch">
            <MerchSection />
          </TabsContent>

          <TabsContent value="your-words">
            <YourWordsSection />
          </TabsContent>

          <TabsContent value="custom">
            <CustomSection />
          </TabsContent>

          <TabsContent value="ai-tools">
            <AIToolsSection />
          </TabsContent>

          <TabsContent value="profile">
            <ProfileSection />
          </TabsContent>
        </Tabs>
      </main>

      {/* Floating Chat Bubble */}
      <FloatingChatBubble />

      {/* Bottom Mobile Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-md border-t border-emerald-500/50">
        <div className="grid grid-cols-6 gap-1 p-2">
          <button
            onClick={() => navigate('/home')}
            className="flex flex-col items-center gap-1 p-2 text-gray-400 hover:text-emerald-400"
          >
            <Home className="w-5 h-5" />
            <span className="text-xs">HOME</span>
          </button>

          {['merch', 'your-words', 'custom', 'ai-tools', 'profile'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex flex-col items-center gap-1 p-2 transition-colors ${
                activeTab === tab ? (tab === 'your-words' || tab === 'profile' ? 'text-cyan-400' : tab === 'ai-tools' ? 'text-amber-400' : tab === 'custom' ? 'text-fuchsia-400' : 'text-emerald-400') : 'text-gray-400'
              }`}
            >
              {tab === 'merch' && <ShoppingBag className="w-5 h-5" />}
              {tab === 'your-words' && <Video className="w-5 h-5" />}
              {tab === 'custom' && <Palette className="w-5 h-5" />}
              {tab === 'ai-tools' && <Sparkles className="w-5 h-5" />}
              {tab === 'profile' && <User className="w-5 h-5" />}
              <span className="text-xs uppercase">{tab === 'your-words' ? 'WORDS' : tab.replace('-', ' ')}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
